bakufuが使用するGIFとAVIFの第三者通知です。

gav1d-COPYING、dav1d-COPYING、libaom-LICENSE、libaom-PATENTS、
GIF89a-ACKNOWLEDGEMENTを同じディレクトリで確認できます。
